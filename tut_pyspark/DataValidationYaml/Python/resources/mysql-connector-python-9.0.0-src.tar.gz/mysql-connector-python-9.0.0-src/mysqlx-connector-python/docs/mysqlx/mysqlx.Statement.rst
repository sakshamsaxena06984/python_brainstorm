mysqlx.Statement
================

.. autoclass:: mysqlx.Statement
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
