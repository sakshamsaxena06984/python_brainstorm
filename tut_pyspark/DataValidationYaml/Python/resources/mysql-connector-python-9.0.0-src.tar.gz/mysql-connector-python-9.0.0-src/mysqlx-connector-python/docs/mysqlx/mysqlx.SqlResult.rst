mysqlx.SqlResult
================

.. autoclass:: mysqlx.SqlResult
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
