mysqlx.IntegrityError
=====================

.. autoclass:: mysqlx.IntegrityError
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
