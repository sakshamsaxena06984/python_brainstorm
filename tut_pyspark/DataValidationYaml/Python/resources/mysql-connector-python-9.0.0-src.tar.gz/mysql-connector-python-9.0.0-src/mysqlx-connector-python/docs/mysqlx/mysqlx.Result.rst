mysqlx.Result
=============

.. autoclass:: mysqlx.Result
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
