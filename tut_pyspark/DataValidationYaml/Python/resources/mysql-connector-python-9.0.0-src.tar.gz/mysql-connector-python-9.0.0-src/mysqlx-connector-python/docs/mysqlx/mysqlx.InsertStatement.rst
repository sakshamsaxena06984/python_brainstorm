mysqlx.InsertStatement
======================

.. autoclass:: mysqlx.InsertStatement
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
