mysqlx.Schema
=============

.. autoclass:: mysqlx.Schema
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
