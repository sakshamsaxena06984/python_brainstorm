mysqlx.DatabaseError
====================

.. autoclass:: mysqlx.DatabaseError
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
