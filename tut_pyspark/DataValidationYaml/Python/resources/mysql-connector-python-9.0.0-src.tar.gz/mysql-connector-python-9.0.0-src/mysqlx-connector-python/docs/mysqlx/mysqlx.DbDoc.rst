mysqlx.DbDoc
============

.. autoclass:: mysqlx.DbDoc
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
