mysqlx.Row
==========

.. autoclass:: mysqlx.Row
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
