mysqlx.SqlStatement
===================

.. autoclass:: mysqlx.SqlStatement
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
