mysqlx.Client
=============

.. autoclass:: mysqlx.Client
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
