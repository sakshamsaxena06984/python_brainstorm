mysqlx.BufferingResult
======================

.. autoclass:: mysqlx.BufferingResult
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
