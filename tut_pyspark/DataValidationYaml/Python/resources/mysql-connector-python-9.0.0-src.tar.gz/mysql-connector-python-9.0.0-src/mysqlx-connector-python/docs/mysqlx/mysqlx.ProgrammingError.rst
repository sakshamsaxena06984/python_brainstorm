mysqlx.ProgrammingError
=======================

.. autoclass:: mysqlx.ProgrammingError
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
