mysqlx.InterfaceError
=====================

.. autoclass:: mysqlx.InterfaceError
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
