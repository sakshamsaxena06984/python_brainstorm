mysqlx.InternalError
====================

.. autoclass:: mysqlx.InternalError
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
