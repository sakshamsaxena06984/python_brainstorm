mysqlx.DeleteStatement
======================

.. autoclass:: mysqlx.DeleteStatement
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
