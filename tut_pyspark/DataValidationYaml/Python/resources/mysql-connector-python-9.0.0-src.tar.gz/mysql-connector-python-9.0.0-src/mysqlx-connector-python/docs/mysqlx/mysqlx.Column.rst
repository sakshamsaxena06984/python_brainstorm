mysqlx.Column
=============

.. autoclass:: mysqlx.Column
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
