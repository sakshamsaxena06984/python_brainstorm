mysqlx.get_session
==================

.. autofunction:: mysqlx.get_session
