mysqlx.View
===========

.. autoclass:: mysqlx.View
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
