mysqlx.PoolError
================

.. autoclass:: mysqlx.PoolError
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
