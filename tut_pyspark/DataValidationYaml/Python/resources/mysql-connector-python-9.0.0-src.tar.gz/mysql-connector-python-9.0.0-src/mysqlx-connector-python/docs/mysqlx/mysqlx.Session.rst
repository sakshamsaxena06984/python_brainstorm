mysqlx.Session
==============

.. autoclass:: mysqlx.Session
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
